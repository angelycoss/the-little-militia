plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.littlemilitia.angelycoss"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.littlemilitia.angelycoss"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "0.0.3"
    }

    signingConfigs {
        create("lm") {
            storeFile = file("littlemilitia.keystore")
            storePassword = "littlemilitia"
            keyAlias = "littlemilitia"
            keyPassword = "littlemilitia"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("lm")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("lm")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("org.java-websocket:Java-WebSocket:1.5.7")
    implementation("org.slf4j:slf4j-nop:1.7.36")
}
