package com.littlemilitia.angelycoss

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface

/** Descubrimiento de partidas por broadcast UDP en la red local. */
class Discovery(private val ctx: Context, private val onHosts: (String) -> Unit) {

    companion object {
        const val PORT = 47877
        const val MAGIC = "LMIL1"

        fun localIps(): List<String> {
            val out = ArrayList<String>()
            try {
                val ifs = NetworkInterface.getNetworkInterfaces()
                while (ifs != null && ifs.hasMoreElements()) {
                    val ni = ifs.nextElement()
                    if (!ni.isUp || ni.isLoopback) continue
                    for (ia in ni.interfaceAddresses) {
                        val a = ia.address
                        if (a is Inet4Address && !a.isLoopbackAddress) out.add(a.hostAddress ?: continue)
                    }
                }
            } catch (e: Exception) {
            }
            return out
        }
    }

    private class Entry(
        val name: String, val ip: String, val port: Int,
        val players: Int, val max: Int, val ver: String, var seen: Long
    )

    @Volatile private var announcing = false
    @Volatile private var listening = false
    @Volatile private var info = ""
    private var annThread: Thread? = null
    private var lisThread: Thread? = null
    private var lock: WifiManager.MulticastLock? = null

    private fun acquireLock() {
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (lock == null) lock = wm.createMulticastLock("littlemilitia").apply { setReferenceCounted(false) }
            lock?.acquire()
        } catch (e: Exception) {
        }
    }

    private fun releaseLock() {
        try {
            if (!announcing && !listening) lock?.release()
        } catch (e: Exception) {
        }
    }

    fun setInfo(name: String, port: Int, players: Int, ver: String) {
        info = "$MAGIC|${name.replace("|", " ")}|$port|$players|${RelayServer.MAX_PLAYERS}|$ver"
    }

    fun startAnnounce() {
        if (announcing) return
        announcing = true
        acquireLock()
        annThread = Thread {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket()
                sock.broadcast = true
                while (announcing) {
                    val data = info.toByteArray(Charsets.UTF_8)
                    val targets = HashSet<String>()
                    targets.add("255.255.255.255")
                    try {
                        val ifs = NetworkInterface.getNetworkInterfaces()
                        while (ifs != null && ifs.hasMoreElements()) {
                            val ni = ifs.nextElement()
                            if (!ni.isUp || ni.isLoopback) continue
                            for (ia in ni.interfaceAddresses) {
                                val b = ia.broadcast
                                if (b != null) targets.add(b.hostAddress ?: continue)
                            }
                        }
                    } catch (e: Exception) {
                    }
                    for (t in targets) {
                        try {
                            sock.send(DatagramPacket(data, data.size, InetAddress.getByName(t), PORT))
                        } catch (e: Exception) {
                        }
                    }
                    Thread.sleep(1000)
                }
            } catch (e: Exception) {
            } finally {
                try {
                    sock?.close()
                } catch (e: Exception) {
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stopAnnounce() {
        announcing = false
        annThread = null
        releaseLock()
    }

    fun startListen() {
        if (listening) return
        listening = true
        acquireLock()
        lisThread = Thread {
            val found = HashMap<String, Entry>()
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket(null)
                sock.reuseAddress = true
                sock.bind(InetSocketAddress(PORT))
                sock.soTimeout = 1000
                val buf = ByteArray(512)
                var lastPush = 0L
                while (listening) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        sock.receive(p)
                        val s = String(p.data, 0, p.length, Charsets.UTF_8).split("|")
                        if (s.size >= 6 && s[0] == MAGIC) {
                            val ip = p.address.hostAddress ?: continue
                            val port = s[2].toIntOrNull() ?: continue
                            found["$ip:$port"] = Entry(
                                s[1], ip, port, s[3].toIntOrNull() ?: 0,
                                s[4].toIntOrNull() ?: 20, s[5], System.currentTimeMillis()
                            )
                        }
                    } catch (e: java.net.SocketTimeoutException) {
                    }
                    val now = System.currentTimeMillis()
                    found.entries.removeAll { now - it.value.seen > 4000 }
                    if (now - lastPush > 900) {
                        lastPush = now
                        val arr = JSONArray()
                        for (e in found.values) {
                            arr.put(
                                JSONObject().put("name", e.name).put("ip", e.ip).put("port", e.port)
                                    .put("players", e.players).put("max", e.max).put("ver", e.ver)
                            )
                        }
                        onHosts(arr.toString())
                    }
                }
            } catch (e: Exception) {
            } finally {
                try {
                    sock?.close()
                } catch (e: Exception) {
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stopListen() {
        listening = false
        lisThread = null
        releaseLock()
    }

    fun stopAll() {
        stopAnnounce()
        stopListen()
    }
}
