package com.littlemilitia.angelycoss

import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * Relé LAN muy simple. El anfitrión (id 0) se conecta a /host.
 * Cliente -> anfitrión: "id|mensaje". Anfitrión -> clientes: "*|mensaje" (todos) o "id|mensaje".
 */
class RelayServer(port: Int, private val onFail: (String) -> Unit) :
    WebSocketServer(InetSocketAddress(port)) {

    companion object {
        const val MAX_PLAYERS = 20
    }

    private val ids = ConcurrentHashMap<WebSocket, Int>()
    private val byId = ConcurrentHashMap<Int, WebSocket>()
    private var nextId = 1

    @Volatile
    private var host: WebSocket? = null

    private fun safeSend(c: WebSocket?, msg: String) {
        try {
            if (c != null && c.isOpen) c.send(msg)
        } catch (e: Exception) {
        }
    }

    init {
        isReuseAddr = true
        isTcpNoDelay = true
        connectionLostTimeout = 10
    }

    override fun onStart() {
    }

    override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
        val isHost = handshake.resourceDescriptor.startsWith("/host")
        if (isHost) {
            if (host != null) {
                conn.close()
                return
            }
            host = conn
            ids[conn] = 0
            byId[0] = conn
            safeSend(conn, "#0")
            return
        }
        if (host == null || byId.size >= MAX_PLAYERS) {
            safeSend(conn, "!full")
            conn.close()
            return
        }
        val id = synchronized(this) { nextId++ }
        ids[conn] = id
        byId[id] = conn
        safeSend(conn, "#$id")
        safeSend(host, "$id|{\"t\":\"join\"}")
    }

    override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
        val id = ids.remove(conn) ?: return
        byId.remove(id)
        if (id == 0) {
            host = null
            for (c in ArrayList(byId.values)) {
                try {
                    c.close()
                } catch (e: Exception) {
                }
            }
            byId.clear()
            ids.clear()
            return
        }
        safeSend(host, "$id|{\"t\":\"leave\"}")
    }

    override fun onMessage(conn: WebSocket, message: String) {
        val id = ids[conn] ?: return
        if (id != 0) {
            safeSend(host, "$id|$message")
            return
        }
        val bar = message.indexOf('|')
        if (bar < 0) return
        val target = message.substring(0, bar)
        val payload = message.substring(bar + 1)
        if (target == "*") {
            for ((cid, c) in byId) {
                if (cid != 0) safeSend(c, payload)
            }
        } else {
            val tid = target.toIntOrNull() ?: return
            safeSend(byId[tid], payload)
        }
    }

    override fun onError(conn: WebSocket?, ex: Exception?) {
        if (conn == null) onFail(ex?.message ?: "error")
    }
}
