package com.littlemilitia.angelycoss

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var server: RelayServer? = null
    private lateinit var disc: Discovery
    private var hostName = "Partida"
    private var hostPort = 8765

    inner class Bridge {
        @JavascriptInterface
        fun version(): String = BuildConfigHelper.versionName(this@MainActivity)

        @JavascriptInterface
        fun localIps(): String = JSONArray(Discovery.localIps()).toString()

        @JavascriptInterface
        fun startHost(name: String, port: Int, ver: String): String {
            return try {
                stopHostInternal()
                hostName = name
                hostPort = port
                val s = RelayServer(port) { msg ->
                    runOnUiThread { js("window.onServerFail&&window.onServerFail(${JSONObject.quote(msg)})") }
                }
                s.start()
                server = s
                disc.setInfo(name, port, 1, ver)
                disc.startAnnounce()
                "ok"
            } catch (e: Exception) {
                "error:" + (e.message ?: "desconocido")
            }
        }

        @JavascriptInterface
        fun hostInfo(players: Int, ver: String) {
            disc.setInfo(hostName, hostPort, players, ver)
        }

        @JavascriptInterface
        fun stopHost() {
            stopHostInternal()
        }

        @JavascriptInterface
        fun startDiscovery() {
            disc.startListen()
        }

        @JavascriptInterface
        fun stopDiscovery() {
            disc.stopListen()
        }

        @JavascriptInterface
        fun vibrate(ms: Int) {
            try {
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms.toLong())
                }
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finish() }
        }
    }

    private fun stopHostInternal() {
        try {
            disc.stopAnnounce()
            server?.stop(200)
        } catch (e: Exception) {
        }
        server = null
    }

    private fun js(code: String) {
        web.evaluateJavascript(code, null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        disc = Discovery(this) { json ->
            runOnUiThread { js("window.onHosts&&window.onHosts(${JSONObject.quote(json)})") }
        }
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = true
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        setContentView(web)
        hideBars()
        web.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack?window.onBack():false)") { r ->
            if (r != "true") super@MainActivity.onBackPressed()
        }
    }

    override fun onDestroy() {
        try {
            disc.stopAll()
            server?.stop(100)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}

object BuildConfigHelper {
    fun versionName(ctx: Context): String {
        return try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "0"
        } catch (e: Exception) {
            "0"
        }
    }
}
