/* Little Militia - interfaz, red LAN, controles y dibujo */
(function () {
  'use strict';
  var LM = window.LM, MAPS = window.MAPS, W = LM.WEAPONS;
  var A = window.Android || { version: function () { return 'dev'; }, localIps: function () { return '[]'; }, startHost: function () { return 'ok'; },
    hostInfo: function () { }, stopHost: function () { }, startDiscovery: function () { }, stopDiscovery: function () { }, vibrate: function () { }, exitApp: function () { } };
  var VER = A.version();
  var COLORS = ['#e53935', '#1e88e5', '#43a047', '#fdd835', '#8e24aa', '#fb8c00', '#00acc1', '#d81b60', '#7cb342', '#6d4c41',
    '#3949ab', '#00897b', '#f4511e', '#c0ca33', '#5e35b1', '#039be5', '#ec407a', '#546e7a', '#ffb300', '#26a69a'];
  var $ = function (id) { return document.getElementById(id); };
  var cv = $('cv'), ctx = cv.getContext('2d');

  var S = { left: {}, joining: false, auto: false, hostKey: null, screen: 'menu', host: false, me: -1, ws: null, port: 8765, players: {}, mapId: 0, tl: 300, phase: 'lobby', rem: 0,
    sim: null, map: null, imgs: {}, zi: 1, board: [] };
  var ZOOMS = [0.8, 1.2, 1.7];
  var fx = [], rings = [], feed = [], cam = { x: 0, y: 0, shake: 0 }, last = 0, snapT = 0, stT = 0, gseq = 0, flash = 0;
  var sw = 800, sh = 400, dpr = 1;

  /* ---------- utilidades UI ---------- */
  function toast(t) { var e = $('toast'); e.textContent = t; e.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(function () { e.style.display = 'none'; }, 3200); }
  function show(name) {
    var all = document.querySelectorAll('.scr'); for (var i = 0; i < all.length; i++) all[i].classList.remove('on');
    if (name !== 'game') $(name).classList.add('on');
    cv.style.display = (name === 'game' || name === 'pause' || name === 'endscr') ? 'block' : 'none';
    if (name === 'pause' || name === 'endscr') S.overlay = name; else S.overlay = null;
    if (name !== 'pause' && name !== 'endscr') S.screen = name;
  }
  function saveName() { var n = $('nameIn').value.trim().slice(0, 12) || 'Novato'; try { localStorage.setItem('lm_name', n); } catch (e) { } return n; }
  function myName() { return saveName(); }
  try { $('nameIn').value = localStorage.getItem('lm_name') || 'Novato'; } catch (e) { }
  $('verTxt').textContent = 'versión ' + VER;
  setTimeout(function () { A.startDiscovery(); }, 400); // búsqueda automática en segundo plano

  /* ---------- sonido ---------- */
  var AC = null;
  function audio() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { } } return AC; }
  function tone(f, d, type, v, slide) {
    var a = audio(); if (!a) return; var o = a.createOscillator(), g = a.createGain();
    o.type = type; o.frequency.value = f; if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f * slide), a.currentTime + d);
    g.gain.value = v; g.gain.exponentialRampToValueAtTime(0.001, a.currentTime + d); o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + d);
  }
  function noise(d, v, f0) {
    var a = audio(); if (!a) return; var n = Math.floor(a.sampleRate * d), b = a.createBuffer(1, n, a.sampleRate), c = b.getChannelData(0);
    for (var i = 0; i < n; i++) c[i] = (Math.random() * 2 - 1) * (1 - i / n);
    var s = a.createBufferSource(), g = a.createGain(), fl = a.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = f0 || 3000;
    g.gain.value = v; s.buffer = b; s.connect(fl); fl.connect(g); g.connect(a.destination); s.start();
  }
  function sfx(name, x, y) {
    var me = S.players[S.me], v = 1;
    if (x !== undefined && me) { v = Math.max(0, 1 - Math.hypot(x - me.x, y - me.y) / 1100); if (v <= 0.02) return; }
    if (name === 'shot') { noise(0.09, 0.25 * v, 2500); tone(180, 0.08, 'square', 0.05 * v, 0.5); }
    else if (name === 'snip') { noise(0.25, 0.4 * v, 1800); tone(90, 0.25, 'sawtooth', 0.08 * v, 0.4); }
    else if (name === 'boom') { noise(0.7, 0.7 * v, 700); tone(70, 0.5, 'sine', 0.3 * v, 0.3); }
    else if (name === 'hit') { tone(300, 0.07, 'triangle', 0.12 * v, 0.5); }
    else if (name === 'pick') { tone(520, 0.08, 'sine', 0.15, 1); setTimeout(function () { tone(780, 0.1, 'sine', 0.15, 1); }, 70); }
    else if (name === 'rl') { tone(900, 0.04, 'square', 0.05 * v, 1); setTimeout(function () { tone(500, 0.05, 'square', 0.05 * v, 1); }, 120); }
    else if (name === 'melee') { noise(0.08, 0.2 * v, 1200); }
  }

  /* ---------- efectos ---------- */
  function part(x, y, vx, vy, life, col, size, g) { if (fx.length > 500) fx.shift(); fx.push({ x: x, y: y, vx: vx, vy: vy, l: life, m: life, c: col, s: size, g: g || 0 }); }
  function doFx(type, x, y) {
    var i;
    if (type === 'spark') for (i = 0; i < 4; i++) part(x, y, (Math.random() - .5) * 160, (Math.random() - .5) * 160, .25, '#ffd24d', 2, 300);
    else if (type === 'smoke') part(x, y, (Math.random() - .5) * 20, (Math.random() - .5) * 20, .5, '#bbb', 4, 0);
    else if (type === 'blood') for (i = 0; i < 6; i++) part(x, y, (Math.random() - .5) * 200, -Math.random() * 150, .5, '#b71c1c', 2.5, 500);
  }
  function boomFx(x, y, r) {
    var i; rings.push({ x: x, y: y, r: 6, mr: r, l: 0.35, m: 0.35 });
    for (i = 0; i < 26; i++) { var a = Math.random() * 6.28, s = Math.random() * r * 3; part(x, y, Math.cos(a) * s, Math.sin(a) * s, .5 + Math.random() * .4, i % 2 ? '#ff9800' : '#ffee58', 3 + Math.random() * 4, 0); }
    for (i = 0; i < 10; i++) part(x, y, (Math.random() - .5) * 120, -Math.random() * 100, 1, '#555', 6, -40);
  }

  /* ---------- mapa e imágenes ---------- */
  function loadMap(id) {
    S.mapId = id; S.map = new LM.GameMap(MAPS[id]);
    if (!S.imgs[id]) { var im = new Image(); im.src = MAPS[id].img; S.imgs[id] = im; }
    S.sim = new LM.Sim(S.map, S.host, simCb()); S.sim.players = S.players; S.sim.active = false;
    fx = []; rings = []; feed = [];
  }
  function simCb() {
    return {
      fx: doFx,
      hit: function (p, o, d, x, y) { toAll({ t: 'h', v: p.id, o: o, d: Math.round(d), x: Math.round(x), y: Math.round(y) }); },
      kill: function (v, o, w) { toAll({ t: 'k', v: v, o: o, w: w }); },
      explosion: function (x, y, r, o, w, g) { toAll({ t: 'exp', x: Math.round(x), y: Math.round(y), r: r, o: o, w: w, g: g }); },
      pickupSpawn: function (pk) { toAll({ t: 'pk+', pk: pk }); },
      pickupGot: function (q, p) { toAll({ t: 'pk-', id: q.id, by: p.id }); if (q.type === 'w' || q.type === 'a') toOne(p.id, { t: 'got', pk: q }); },
      respawn: function (p, x, y) { toAll({ t: 'rs', id: p.id, x: Math.round(x), y: Math.round(y) }); }
    };
  }

  /* ---------- red ---------- */
  function wsOpen() { return S.ws && S.ws.readyState === 1; }
  function toAll(o) { if (wsOpen()) S.ws.send('*|' + JSON.stringify(o)); onEvent(o); }
  function toOne(id, o) { if (id === 0) onEvent(o); else if (wsOpen()) S.ws.send(id + '|' + JSON.stringify(o)); }
  function toHost(o) { if (S.host) hostMsg(0, o); else if (wsOpen()) S.ws.send(JSON.stringify(o)); }

  function roster() { var r = []; for (var id in S.players) r.push({ id: +id, name: S.players[id].name, color: S.players[id].color, rd: S.players[id].ready ? 1 : 0 }); return r; }
  function addPlayer(id, name) {
    var p = S.players[id]; if (!p) { p = S.players[id] = LM.newPlayer(id, name, COLORS[id % 20]); } else p.name = name; return p;
  }
  function pushRoster() { toAll({ t: 'pl', r: roster() }); A.hostInfo(Object.keys(S.players).length, VER); }

  function hostMsg(id, m) {
    var p = S.players[id], sim = S.sim, i;
    switch (m.t) {
      case 'hello':
        if (m.ver !== VER) { toOne(id, { t: 'reject', m: 'Versión distinta: el anfitrión usa ' + VER + ' y tú ' + m.ver + '. Instala la misma versión.' }); return; }
        p = addPlayer(id, String(m.name || 'J' + id).slice(0, 12));
        var wel = { t: 'welcome', id: id, phase: S.phase, map: S.mapId, tl: S.tl, rem: Math.ceil(S.rem), r: roster(), pk: sim ? sim.pk : [] };
        if (S.phase === 'play' && sim) { var sp = sim.pickSpawn(); sim.respawnAt(p, sp[0], sp[1]); wel.sp = [sp[0], sp[1]]; }
        toOne(id, wel); pushRoster(); toAll({ t: 'cfg', map: S.mapId, tl: S.tl });
        break;
      case 'leave':
        delete S.players[id]; pushRoster(); toast('Un jugador salió'); break;
      case 's':
        if (p && p.alive && m.p) { var a = m.p; p.x = a[0]; p.y = a[1]; p.vx = a[2]; p.vy = a[3]; p.aim = a[4]; p.face = a[5]; p.jet = !!a[6]; p.cw = [a[7], a[8], a[9]]; p.lastSeen = performance.now(); }
        break;
      case 'fire':
        if (!p || !p.alive || !sim) return;
        if (id !== 0) for (i = 0; i < m.b.length; i++) sim.addProj({ o: id, w: m.w, type: W[m.w].rocket ? 'r' : 'b', x: m.b[i][0], y: m.b[i][1], vx: m.b[i][2], vy: m.b[i][3], life: W[m.w].life });
        toAll({ t: 'b', o: id, w: m.w, b: m.b }); break;
      case 'gren':
        if (!p || !p.alive || !sim) return;
        if (id !== 0) sim.addProj({ o: id, type: 'g', gid: m.g, x: m.x, y: m.y, vx: m.vx, vy: m.vy, fuse: 2.2 });
        toAll({ t: 'g', o: id, g: m.g, x: m.x, y: m.y, vx: m.vx, vy: m.vy }); break;
      case 'ready': if (p && S.phase === 'lobby') { p.ready = !!m.v; pushRoster(); } break;
      case 'take': if (p && p.alive && sim) sim.take(p, m.id); break;
      case 'drop': if (p && sim && m.w >= 0 && m.w < W.length) sim.dropWeapon(p, m.w); break;
      case 'melee':
        if (!p || !p.alive || !sim) return;
        sim.melee(id, p.x, p.y, p.face); toAll({ t: 'm', o: id }); break;
    }
  }

  function wsOf(p, isMe) {
    var w = isMe ? [p.w[0], p.w[1], p.wb] : (p.cw || [0, 0, -1]);
    function g(v, d) { return (typeof v === 'number' && v >= 0 && v < W.length) ? v : d; }
    return [g(w[0], 0), g(w[1], 0), g(w[2], -1)];
  }
  function snapshot() {
    var a = [], id, p, r = Math.round, w;
    for (id in S.players) {
      p = S.players[id]; w = wsOf(p, +id === S.me);
      a.push([+id, r(p.x * 10) / 10, r(p.y * 10) / 10, r(p.vx), r(p.vy), r(p.aim * 100) / 100, p.face, p.jet ? 1 : 0, w[0], w[1], w[2], r(p.hp), r(p.armor), p.alive ? 1 : 0, p.kills, p.deaths]);
    }
    return { t: 'S', r: Math.ceil(S.rem), p: a };
  }

  function onEvent(m) {
    var me = S.players[S.me], i, p, sim = S.sim;
    switch (m.t) {
      case 'welcome':
        S.joining = false; S.auto = false; A.stopDiscovery();
        S.me = m.id; S.mapId = m.map; S.tl = m.tl; S.phase = m.phase; S.rem = m.rem; applyRoster(m.r);
        if (m.phase === 'play') {
          loadMap(m.map); sim = S.sim; sim.active = false; sim.pk = m.pk || [];
          if (m.sp) { sim.respawnAt(S.players[S.me], m.sp[0], m.sp[1]); }
          startGameUI();
        } else { showLobby(); }
        break;
      case 'reject': if (!S.auto) toast(m.m); leaveAll(); break;
      case 'pl': applyRoster(m.r); if (S.screen === 'lobby') renderLobby(); break;
      case 'cfg': S.mapId = m.map; S.tl = m.tl; if (S.screen === 'lobby') renderLobby(); break;
      case 'start':
        if (!S.host) {
          loadMap(m.map); sim = S.sim; sim.active = false;
          for (var id in m.sp) { p = S.players[id]; if (p) { p.kills = 0; p.deaths = 0; sim.respawnAt(p, m.sp[id][0], m.sp[id][1]); } }
        }
        S.phase = 'play'; S.rem = m.tl; S.board = []; startGameUI(); break;
      case 'S':
        if (S.host) break;
        S.rem = m.r;
        for (i = 0; i < m.p.length; i++) {
          var q = m.p[i]; p = S.players[q[0]]; if (!p) continue;
          p.hp = q[11]; p.armor = q[12]; p.kills = q[14]; p.deaths = q[15];
          if (q[0] === S.me) { if (!q[13] && p.alive) { p.alive = false; } }
          else {
            var was = p.alive; p.x = q[1]; p.y = q[2]; p.vx = q[3]; p.vy = q[4]; p.aim = q[5]; p.face = q[6]; p.jet = !!q[7]; p.cw = [q[8], q[9], q[10]]; p.alive = !!q[13];
            if (p.alive && !was) { p.rx = p.x; p.ry = p.y; }
          }
        }
        break;
      case 'b':
        if (S.host || m.o === S.me || !sim) break;
        for (i = 0; i < m.b.length; i++) sim.addProj({ o: m.o, w: m.w, type: W[m.w].rocket ? 'r' : 'b', x: m.b[i][0], y: m.b[i][1], vx: m.b[i][2], vy: m.b[i][3], life: W[m.w].life });
        p = S.players[m.o]; if (p) { muzzle(p, m.w, (p.cw && p.cw[1] === m.w && p.cw[0] !== m.w) ? 1 : 0); sfx(m.w === 4 ? 'snip' : 'shot', p.x, p.y); }
        break;
      case 'g':
        if (S.host || m.o === S.me || !sim) break;
        sim.addProj({ o: m.o, type: 'g', gid: m.g, x: m.x, y: m.y, vx: m.vx, vy: m.vy, fuse: 2.2 }); break;
      case 'm': p = S.players[m.o]; if (p) { p.swing = 0.2; sfx('melee', p.x, p.y); } break;
      case 'h':
        doFx('blood', m.x, m.y); sfx('hit', m.x, m.y);
        if (m.v === S.me) { flash = 0.35; A.vibrate(25); }
        break;
      case 'k':
        p = S.players[m.v];
        var kn = p ? p.name : '?', on = S.players[m.o] ? S.players[m.o].name : '?';
        feed.push({ t: 5, s: m.v === m.o ? kn + ' se suicidó' : on + ' eliminó a ' + kn + ' (' + LM.wname(m.w) + ')', mine: m.o === S.me || m.v === S.me });
        if (feed.length > 5) feed.shift();
        if (p) { if (!S.host) { p.alive = false; p.resp = 4; } for (i = 0; i < 14; i++) part(p.x, p.y - 15, (Math.random() - .5) * 220, -Math.random() * 220, .8, '#b71c1c', 3, 600); }
        break;
      case 'exp':
        boomFx(m.x, m.y, m.r); sfx('boom', m.x, m.y);
        if (!S.host && sim) for (i = sim.proj.length - 1; i >= 0; i--) if (sim.proj[i].type === 'g' && sim.proj[i].gid === m.g) sim.proj.splice(i, 1);
        if (me && me.alive) {
          var d = Math.hypot(me.x - m.x, (me.y - 15) - m.y);
          if (d < m.r) { var f = 1 - d / m.r, dx = (me.x - m.x) / (d || 1), dy = ((me.y - 15) - m.y) / (d || 1); me.vx += dx * 520 * f; me.vy += dy * 520 * f - 60; }
        }
        if (me) cam.shake = Math.max(cam.shake, Math.max(0, 1 - Math.hypot(me.x - m.x, me.y - m.y) / 700) * 9);
        break;
      case 'rs':
        p = S.players[m.id]; if (!p) break;
        if (!S.host || p.id !== S.me) { if (sim) sim.respawnAt(p, m.x, m.y); }
        if (m.id === S.me) { cam.x = m.x; cam.y = m.y; me = p; }
        break;
      case 'pk+': if (!S.host && sim) sim.pk.push(m.pk); break;
      case 'pk-':
        if (!S.host && sim) for (i = sim.pk.length - 1; i >= 0; i--) if (sim.pk[i].id === m.id) sim.pk.splice(i, 1);
        if (m.by === S.me) sfx('pick');
        break;
      case 'got': if (me) { var dropped = LM.applyPickup(me, m.pk); if (dropped >= 0) toHost({ t: 'drop', w: dropped }); sfx('pick'); } break;
      case 'end':
        S.phase = 'end'; S.board = m.board; if (sim) sim.active = false; showEnd(); break;
      case 'lobby':
        S.phase = 'lobby'; showLobby(); break;
    }
  }
  function applyRoster(r) {
    var keep = {}, i;
    for (i = 0; i < r.length; i++) { keep[r[i].id] = 1; var p = addPlayer(r[i].id, r[i].name); p.color = r[i].color; p.ready = !!r[i].rd; }
    for (var id in S.players) if (!keep[id]) delete S.players[id];
  }

  /* ---------- conexión ---------- */
  function setupWs(ws, isHost) {
    S.ws = ws;
    ws.onmessage = function (e) {
      var d = e.data;
      if (isHost) {
        if (d.charAt(0) === '#') return;
        var b = d.indexOf('|'); if (b < 0) return;
        var id = +d.substring(0, b), m; try { m = JSON.parse(d.substring(b + 1)); } catch (x) { return; }
        hostMsg(id, m);
      } else {
        if (d.charAt(0) === '#') { S.me = +d.substring(1); ws.send(JSON.stringify({ t: 'hello', name: myName(), ver: VER })); return; }
        if (d === '!full') { if (!S.auto) toast('La partida está llena o no existe'); leaveAll(); return; }
        try { onEvent(JSON.parse(d)); } catch (x) { }
      }
    };
    ws.onclose = function () { if (S.ws === ws) { var was = S.screen !== 'menu'; if (was) toast(isHost ? 'Servidor cerrado' : 'Se perdió la conexión con el anfitrión'); leaveAll(); } };
    ws.onerror = function () { };
  }

  function startHost() {
    A.stopDiscovery();
    var name = myName(), res = A.startHost(name, S.port, VER);
    if (res !== 'ok') { toast('No se pudo crear la partida: ' + res); A.startDiscovery(); return; }
    S.host = true; S.me = 0; S.players = {}; S.phase = 'lobby'; S.joining = false;
    var p = addPlayer(0, name); p.color = COLORS[0];
    setTimeout(function () {
      var ws = new WebSocket('ws://127.0.0.1:' + S.port + '/host');
      ws.onopen = function () { setupWs(ws, true); showLobby(); };
      ws.onerror = function () { toast('Error al iniciar el servidor local'); leaveAll(); };
    }, 350);
  }

  // silent = unión automática (sin avisos)
  function joinGame(ip, port, silent) {
    ip = (ip || '').trim(); if (!ip) { if (!silent) toast('Escribe la IP del anfitrión'); return; }
    port = port || 8765; S.host = false; S.players = {}; S.joining = true; S.auto = !!silent; S.hostKey = ip + ':' + port;
    var ws, to;
    function fail() {
      clearTimeout(to); S.joining = false; S.auto = false;
      if (silent) S.left[S.hostKey] = { until: Date.now() + 10000 }; else toast('No se pudo conectar');
    }
    try { ws = new WebSocket('ws://' + ip + ':' + port + '/'); } catch (e) { fail(); return; }
    if (!silent) toast('Conectando...');
    to = setTimeout(function () { if (ws.readyState !== 1) { try { ws.close(); } catch (e) { } fail(); } }, 6000);
    ws.onopen = function () { clearTimeout(to); setupWs(ws, false); };
    ws.onerror = function () { fail(); };
  }

  function leaveAll() {
    var ws = S.ws; S.ws = null;
    if (ws) { try { ws.close(); } catch (e) { } }
    if (S.host) A.stopHost();
    else if (S.hostKey) S.left[S.hostKey] = { until: Infinity }; // no volver a entrar solo a la partida que acabas de dejar
    S.hostKey = null; S.joining = false; S.auto = false;
    S.host = false; S.me = -1; S.players = {}; S.sim = null; S.phase = 'lobby'; S.rem = 0;
    show('menu'); A.startDiscovery();
  }

  /* ---------- pantallas ---------- */
  function renderHosts(arr) {
    var box = $('hostList'); box.innerHTML = '';
    if (!arr.length) { box.innerHTML = '<div class="small">Buscando partidas... (también puedes escribir la IP)</div>'; return; }
    arr.forEach(function (h) {
      var d = document.createElement('div'); d.className = 'host';
      d.innerHTML = '<span><b></b> <span class="small"></span></span><span class="btn sm">Entrar</span>';
      d.querySelector('b').textContent = h.name; d.querySelector('.small').textContent = h.players + '/' + h.max + ' · v' + h.ver + ' · ' + h.ip;
      d.onclick = function () { joinGame(h.ip, h.port); }; box.appendChild(d);
    });
  }
  // Búsqueda automática: en el menú principal, si hay una partida abierta compatible se entra sin avisar
  function autoJoin(arr) {
    var ok = arr.filter(function (h) { var l = S.left[h.ip + ':' + h.port]; return !l && h.players < h.max && h.ver === VER; });
    ok.sort(function (x, y) { return y.players - x.players; });
    if (ok.length) { joinGame(ok[0].ip, ok[0].port, true); return; }
    var other = arr.filter(function (h) { return h.ver !== VER; });
    $('autoMsg').textContent = other.length ? 'Hay una partida con otra versión (v' + other[0].ver + '). Actualiza el juego para unirte.' : 'Buscando partidas en tu red…';
  }
  window.onHosts = function (json) {
    var arr = []; try { arr = JSON.parse(json); } catch (e) { }
    var now = Date.now(), seen = {}, k;
    arr.forEach(function (h) { seen[h.ip + ':' + h.port] = 1; });
    for (k in S.left) { var l = S.left[k]; if (l.until === Infinity ? !seen[k] : now > l.until) delete S.left[k]; }
    if (S.screen === 'join') renderHosts(arr);
    else if (S.screen === 'menu' && !S.overlay && !S.joining && !S.host && !S.ws) autoJoin(arr);
  };
  window.onServerFail = function (m) { toast('Error del servidor: ' + m); };

  function showLobby() {
    show('lobby'); S.screen = 'lobby'; renderLobby();
    if (S.host) { var ips = []; try { ips = JSON.parse(A.localIps()); } catch (e) { } $('lobIps').textContent = 'IP para unirse manualmente: ' + (ips.join('  ·  ') || '(sin red)') + '   puerto ' + S.port; }
    else $('lobIps').textContent = '';
    if (!S.imgs[S.mapId]) { var im = new Image(); im.src = MAPS[S.mapId].img; S.imgs[S.mapId] = im; }
  }
  function renderLobby() {
    var l = $('lobList'), n = 0; l.innerHTML = '';
    for (var id in S.players) {
      n++; var p = S.players[id], d = document.createElement('div'); d.className = 'pl';
      d.innerHTML = '<span class="dot"></span><span></span>'; d.firstChild.style.background = p.color;
      d.lastChild.textContent = p.name + (+id === 0 ? ' (anfitrión)' : (p.ready ? ' ✓ listo' : '')) + (+id === S.me ? ' ← tú' : ''); l.appendChild(d);
    }
    var others = 0, ready = 0, me0 = S.players[S.me];
    for (id in S.players) if (+id !== 0) { others++; if (S.players[id].ready) ready++; }
    $('lobCount').textContent = n; $('lobTitle').textContent = S.host ? 'Tu partida' : 'Sala de espera';
    $('cfgHost').style.display = S.host ? 'block' : 'none'; $('bStart').style.display = S.host ? 'block' : 'none';
    $('cfgInfo').textContent = S.host ? '' : 'Mapa: ' + MAPS[S.mapId].name + ' · ' + (S.tl / 60) + ' min. Esperando al anfitrión...';
    $('bStart').classList.toggle('dis', S.host && ready < others);
    $('bReady').style.display = S.host ? 'none' : 'block';
    $('bReady').textContent = me0 && me0.ready ? 'Cancelar (estoy listo)' : 'Listo';
    $('bReady').classList.toggle('sel', !!(me0 && me0.ready));
    $('readyInfo').textContent = S.host ? (others ? 'Listos: ' + ready + '/' + others + (ready < others ? ' — esperando a los demás' : ' — ¡todos listos!') : 'Solo tú en la sala (puedes empezar)')
      : (me0 && me0.ready ? 'Esperando a que el anfitrión inicie...' : 'Pulsa "Listo" cuando quieras jugar');
    var mb = $('mapBtns'); mb.innerHTML = '';
    MAPS.forEach(function (mp, i) {
      var b = document.createElement('div'); b.className = 'btn sm' + (i === S.mapId ? ' sel' : ''); b.textContent = mp.name;
      b.onclick = function () { S.mapId = i; if (!S.imgs[i]) { var im = new Image(); im.src = MAPS[i].img; S.imgs[i] = im; } toAll({ t: 'cfg', map: i, tl: S.tl }); renderLobby(); }; mb.appendChild(b);
    });
    var tb = $('timeBtns'); tb.innerHTML = '';
    [180, 300, 600, 900].forEach(function (t) {
      var b = document.createElement('div'); b.className = 'btn sm' + (t === S.tl ? ' sel' : ''); b.textContent = (t / 60) + ' min';
      b.onclick = function () { S.tl = t; toAll({ t: 'cfg', map: S.mapId, tl: t }); renderLobby(); }; tb.appendChild(b);
    });
  }
  function hostStart() {
    for (var pid in S.players) if (+pid !== 0 && !S.players[pid].ready) { toast('Esperando a que todos los jugadores estén listos'); return; }
    loadMap(S.mapId); var sim = S.sim; sim.active = true; sim.resetMatch();
    S.phase = 'play'; S.rem = S.tl;
    var sp = {}; for (var id in S.players) sp[id] = [Math.round(S.players[id].x), Math.round(S.players[id].y)];
    toAll({ t: 'start', map: S.mapId, tl: S.tl, sp: sp });
  }
  function startGameUI() { show('game'); S.screen = 'game'; fx = []; feed = []; var me = S.players[S.me]; if (me) { cam.x = me.x; cam.y = me.y; } resize(); }
  function showEnd() {
    var rows = '<tr><th>#</th><th>Jugador</th><th>Muertes</th><th>Bajas</th><th>Puntos</th></tr>';
    S.board.forEach(function (b, i) {
      var p = S.players[b[0]], mine = b[0] === S.me;
      rows += '<tr' + (mine ? ' style="background:#ffffff22;font-weight:bold"' : '') + '><td>' + (i + 1) + '</td><td style="color:' + (p ? p.color : '#fff') + '">' + (p ? p.name : '?') + '</td><td>' + b[2] + '</td><td>' + b[1] + '</td><td>' + b[3] + '</td></tr>';
    });
    $('board').innerHTML = rows; $('bAgain').style.display = S.host ? 'block' : 'none'; show('endscr');
  }
  // Puntos = bajas - muertes (un suicidio cuenta como muerte y además descuenta una baja)
  function endMatch() {
    var b = []; for (var id in S.players) { var p = S.players[id]; b.push([+id, p.kills, p.deaths, p.kills - p.deaths]); }
    b.sort(function (x, y) { return y[3] - x[3] || y[1] - x[1] || x[2] - y[2]; }); toAll({ t: 'end', board: b });
  }

  $('bHost').onclick = function () { saveName(); startHost(); };
  $('bJoin').onclick = function () { saveName(); show('join'); S.screen = 'join'; $('hostList').innerHTML = '<div class="small">Buscando partidas...</div>'; A.startDiscovery(); };
  $('bHelp').onclick = function () { show('help'); S.screen = 'help'; };
  $('bExit').onclick = function () { A.exitApp(); };
  $('bJoinBack').onclick = function () { show('menu'); };
  $('bConn').onclick = function () { saveName(); joinGame($('ipIn').value, +$('portIn').value || 8765); };
  $('bLobBack').onclick = leaveAll;
  $('bStart').onclick = hostStart;
  $('bReady').onclick = function () { var me = S.players[S.me]; if (!me) return; me.ready = !me.ready; toHost({ t: 'ready', v: me.ready }); renderLobby(); };
  $('bResume').onclick = function () { show('game'); S.screen = 'game'; };
  $('bLeave').onclick = leaveAll;
  $('bEndLeave').onclick = leaveAll;
  $('bAgain').onclick = function () { S.phase = 'lobby'; for (var id in S.players) S.players[id].ready = false; pushRoster(); toAll({ t: 'lobby' }); };
  document.querySelectorAll('[data-go]').forEach(function (e) { e.onclick = function () { show(e.getAttribute('data-go')); }; });
  window.onBack = function () {
    if (S.overlay === 'pause') { $('bResume').onclick(); return true; }
    if (S.screen === 'game' && S.overlay !== 'endscr') { show('pause'); return true; }
    if (S.overlay === 'endscr') { leaveAll(); return true; }
    if (S.screen === 'lobby') { leaveAll(); return true; }
    if (S.screen === 'join') { show('menu'); return true; }
    if (S.screen === 'help') { show('menu'); return true; }
    return false;
  };

  /* ---------- controles táctiles ---------- */
  var touches = {}, stL = null, stR = null, SR = 55;
  function buttons() {
    var l = [{ k: 'zoom', x: 28, y: 30, r: 19, t: 'Z' }, { k: 'pause', x: sw / 2 + 86, y: 22, r: 15, t: 'II' },
      { k: 'wp', x: sw - 28, y: 34, r: 21, t: '' },
      { k: 'gr', x: sw / 2 - 74, y: sh - 46, r: 28, t: '' }, { k: 'ml', x: sw / 2 + 74, y: sh - 46, r: 28, t: '' }];
    if (S.near) l.push({ k: 'take', x: sw / 2, y: sh - 100, r: 27, t: 'Tomar' });
    return l;
  }
  function press(k) {
    var me = S.players[S.me]; audio();
    if (k === 'zoom') S.zi = (S.zi + 1) % 3;
    else if (k === 'pause') show('pause');
    else if (!me || !me.alive) return;
    else if (k === 'wp') { if (LM.cycleWeapons(me)) sfx('rl'); else toast('No llevas ningún arma guardada en la espalda'); }
    else if (k === 'take') { if (S.near) { toHost({ t: 'take', id: S.near.id }); S.near = null; } }
    else if (k === 'gr') throwGren(me);
    else if (k === 'ml') doMelee(me);
  }
  cv.addEventListener('touchstart', function (e) {
    e.preventDefault();
    for (var i = 0; i < e.changedTouches.length; i++) {
      var t = e.changedTouches[i], x = t.clientX, y = t.clientY, hit = null, bs = buttons();
      for (var j = 0; j < bs.length; j++) if (Math.hypot(x - bs[j].x, y - bs[j].y) < bs[j].r + 10) { hit = bs[j]; break; }
      if (hit) { touches[t.identifier] = 'B'; press(hit.k); continue; }
      if (x < sw / 2 && !stL) { stL = { id: t.identifier, sx: x, sy: y, x: x, y: y }; touches[t.identifier] = 'L'; }
      else if (x >= sw / 2 && !stR) { stR = { id: t.identifier, sx: x, sy: y, x: x, y: y }; touches[t.identifier] = 'R'; }
    }
  }, { passive: false });
  cv.addEventListener('touchmove', function (e) {
    e.preventDefault();
    for (var i = 0; i < e.changedTouches.length; i++) {
      var t = e.changedTouches[i];
      if (stL && stL.id === t.identifier) { stL.x = t.clientX; stL.y = t.clientY; }
      if (stR && stR.id === t.identifier) { stR.x = t.clientX; stR.y = t.clientY; }
    }
  }, { passive: false });
  function endTouch(e) {
    e.preventDefault();
    for (var i = 0; i < e.changedTouches.length; i++) {
      var id = e.changedTouches[i].identifier;
      if (stL && stL.id === id) stL = null; if (stR && stR.id === id) stR = null; delete touches[id];
    }
  }
  cv.addEventListener('touchend', endTouch, { passive: false });
  cv.addEventListener('touchcancel', endTouch, { passive: false });
  function stick(s) {
    if (!s) return { x: 0, y: 0, m: 0 };
    var dx = (s.x - s.sx) / SR, dy = (s.y - s.sy) / SR, m = Math.hypot(dx, dy);
    if (m > 1) { dx /= m; dy /= m; m = 1; } return { x: dx, y: dy, m: m };
  }

  /* ---------- acciones del jugador local ---------- */
  var OFF = [2, -3]; // separación de cada mano respecto a la línea de apuntado
  function gunPos(p, slot, wid) {
    var w = W[wid], a = p.aim, f = Math.cos(a) < 0 ? -1 : 1;
    return [p.x + Math.cos(a) * w.gl - Math.sin(a) * OFF[slot] * f, p.y - 19 + Math.sin(a) * w.gl + Math.cos(a) * OFF[slot] * f];
  }
  function muzzle(p, wid, slot) {
    var g = gunPos(p, slot || 0, wid), a = p.aim;
    for (var i = 0; i < 3; i++) part(g[0], g[1], Math.cos(a) * 120 + (Math.random() - .5) * 80, Math.sin(a) * 120 + (Math.random() - .5) * 80, .12, '#ffe082', 3, 0);
  }
  function shoot(p, slot) {
    var wid = p.w[slot], w = W[wid], a = p.aim, b = [], k, ang, sp, vx, vy, g = gunPos(p, slot, wid);
    for (k = 0; k < w.pel; k++) {
      ang = a + (Math.random() * 2 - 1) * w.spr; sp = w.spd * (1 + (w.pel > 1 ? (Math.random() - .5) * 0.12 : 0));
      vx = Math.round(Math.cos(ang) * sp); vy = Math.round(Math.sin(ang) * sp);
      b.push([Math.round(g[0] * 10) / 10, Math.round(g[1] * 10) / 10, vx, vy]);
      S.sim.addProj({ o: p.id, w: wid, type: w.rocket ? 'r' : 'b', x: g[0], y: g[1], vx: vx, vy: vy });
    }
    toHost({ t: 'fire', w: wid, b: b });
    p.cd[slot] = w.rate; muzzle(p, wid, slot); sfx(wid === 4 ? 'snip' : 'shot');
    if (wid === 3 || wid === 5) { cam.shake = Math.max(cam.shake, 4); p.vx -= Math.cos(a) * 60; }
    part(p.x, p.y - 18, -Math.cos(a) * 40 + (Math.random() - .5) * 40, -80, .5, '#d4a017', 2, 600);
  }
  // La granada sale en la dirección en que apuntan las manos
  function throwGren(p) {
    if (p.gcd > 0 || p.gren <= 0) return;
    var a = p.aim, vx = Math.round(Math.cos(a) * 420 + p.vx * 0.5), vy = Math.round(Math.sin(a) * 420), gid = S.me + ':' + (++gseq);
    p.gren--; p.gcd = 0.6;
    S.sim.addProj({ o: p.id, type: 'g', gid: gid, x: p.x, y: p.y - 20, vx: vx, vy: vy, fuse: 2.2 });
    toHost({ t: 'gren', g: gid, x: Math.round(p.x), y: Math.round(p.y - 20), vx: vx, vy: vy });
  }
  function doMelee(p) {
    if (p.mcd > 0) return; p.mcd = 0.55; p.swing = 0.2; sfx('melee'); toHost({ t: 'melee' });
  }

  function updateMe(dt) {
    var p = S.players[S.me]; if (!p || !S.map) return;
    var L = stick(stL), R = stick(stR), sim = S.sim;
    p.cw = [p.w[0], p.w[1], p.wb];
    if (!p.alive) {
      S.near = null; LM.physPlayer(S.map, p, dt, null); p.rx = p.x; p.ry = p.y; if (!S.host) p.resp -= dt; return;
    }
    var mx = Math.abs(L.x) > 0.18 ? L.x : 0, up = L.y < -0.5;
    LM.physPlayer(S.map, p, dt, { mx: mx, up: up });
    if (R.m > 0.15) { p.aim = Math.atan2(R.y, R.x); p.face = Math.cos(p.aim) >= 0 ? 1 : -1; }
    else { if (Math.abs(mx) > 0.3) p.face = mx > 0 ? 1 : -1; p.aim = p.face > 0 ? 0 : Math.PI; }
    p.cd[0] -= dt; p.cd[1] -= dt; p.mcd -= dt; p.gcd -= dt; if (p.swing > 0) p.swing -= dt; if (p.hurt > 0) p.hurt -= dt;
    if (R.m > 0.55) { for (var sl = 0; sl < 2; sl++) if (p.cd[sl] <= 0) shoot(p, sl); } // ambas manos a la vez, balas infinitas
    S.near = null;
    for (var qi = 0; qi < sim.pk.length; qi++) {
      var q = sim.pk[qi];
      if (q.type === 'w' && Math.abs(p.x - q.x) < 26 && Math.abs((p.y - 14) - (q.y - 8)) < 26 && p.w.indexOf(q.w) < 0 && p.wb !== q.w) { S.near = q; break; }
    }
    if (p.jet && Math.random() < 0.7) part(p.x - p.face * 6, p.y - 8, (Math.random() - .5) * 30, 120 + Math.random() * 60, .25, Math.random() < .5 ? '#ffb300' : '#ff7043', 3, 0);
    p.rx = p.x; p.ry = p.y;
    stT += dt;
    if (!S.host && stT > 0.033) {
      stT = 0; var r = Math.round;
      toHost({ t: 's', p: [r(p.x * 10) / 10, r(p.y * 10) / 10, r(p.vx), r(p.vy), r(p.aim * 100) / 100, p.face, p.jet ? 1 : 0, p.w[0], p.w[1], p.wb] });
    }
  }

  function updateGame(dt) {
    var sim = S.sim, id, p, i; if (!sim) return;
    sim.update(dt);
    updateMe(dt);
    for (id in S.players) {
      p = S.players[id]; if (+id === S.me) continue;
      var k = Math.min(1, dt * 14); p.rx += (p.x - p.rx) * k; p.ry += (p.y - p.ry) * k;
      if (Math.abs(p.x - p.rx) > 150) { p.rx = p.x; p.ry = p.y; }
      p.sx += Math.abs(p.vx) * dt * 0.09; if (p.swing > 0) p.swing -= dt;
      if (p.jet && Math.random() < 0.5) part(p.rx - p.face * 6, p.ry - 8, (Math.random() - .5) * 30, 120, .25, '#ff9800', 3, 0);
    }
    if (S.host && S.phase === 'play') {
      S.rem -= dt; snapT += dt;
      if (snapT > 0.066) { snapT = 0; if (wsOpen()) S.ws.send('*|' + JSON.stringify(snapshot())); }
      if (S.rem <= 0) { S.rem = 0; endMatch(); }
    } else if (S.phase === 'play') S.rem = Math.max(0, S.rem - dt);
    for (i = fx.length - 1; i >= 0; i--) { var f = fx[i]; f.l -= dt; if (f.l <= 0) { fx.splice(i, 1); continue; } f.vy += f.g * dt; f.x += f.vx * dt; f.y += f.vy * dt; }
    for (i = rings.length - 1; i >= 0; i--) { var r = rings[i]; r.l -= dt; if (r.l <= 0) rings.splice(i, 1); else r.r = r.mr * (1 - r.l / r.m); }
    for (i = feed.length - 1; i >= 0; i--) { feed[i].t -= dt; if (feed[i].t <= 0) feed.splice(i, 1); }
    if (flash > 0) flash -= dt; cam.shake *= Math.max(0, 1 - dt * 6);
    var me = S.players[S.me];
    if (me) { cam.x += (me.x - cam.x) * Math.min(1, dt * 7); cam.y += ((me.y - 18) - cam.y) * Math.min(1, dt * 7); }
  }

  /* ---------- dibujo ---------- */
  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2); sw = window.innerWidth; sh = window.innerHeight;
    cv.width = Math.round(sw * dpr); cv.height = Math.round(sh * dpr);
  }
  window.addEventListener('resize', resize); resize();

  function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

  function drawGun(wid, fl) {
    var w = W[wid]; ctx.fillStyle = w.col; ctx.strokeStyle = '#111'; ctx.lineWidth = 1;
    ctx.fillRect(-2, -w.gh / 2, w.gl + 2, w.gh); ctx.strokeRect(-2, -w.gh / 2, w.gl + 2, w.gh);
    ctx.fillStyle = '#222'; ctx.fillRect(2, w.gh / 2, 4, 5);
    if (wid === 4) { ctx.fillStyle = '#111'; ctx.fillRect(8, -w.gh / 2 - 3, 8, 3); }
    if (wid === 5) { ctx.fillStyle = '#333'; ctx.fillRect(w.gl - 4, -w.gh / 2 - 1, 6, w.gh + 2); }
  }
  function drawPlayer(p, x, y, isMe) {
    var f = p.face || 1, ws = wsOf(p, isMe), w0 = ws[0], w1 = ws[1], wb = ws[2];
    ctx.save(); ctx.translate(x, y);
    if (!p.alive) { ctx.rotate(f * 1.45); ctx.globalAlpha = 0.85; }
    var sw2 = Math.sin(p.sx * 3) * (p.onGround === false || p.jet ? 2 : 5);
    ctx.strokeStyle = '#111'; ctx.lineWidth = 1.2;
    if (wb >= 0) { ctx.save(); ctx.translate(-f * 4, -12); ctx.scale(f, 1); ctx.rotate(-2.4); drawGun(wb); ctx.restore(); } // arma guardada en la espalda
    ctx.fillStyle = '#2b2b2b'; ctx.fillRect(-5 + sw2 * 0.4, -10, 4, 10); ctx.fillRect(1 - sw2 * 0.4, -10, 4, 10);
    if (p.jet) { ctx.fillStyle = '#ffb300'; ctx.beginPath(); ctx.moveTo(-f * 9, -12); ctx.lineTo(-f * 6, -12); ctx.lineTo(-f * 7.5, -2 + Math.random() * 6); ctx.fill(); }
    ctx.fillStyle = '#4a4f55'; ctx.fillRect(-f * 10 - 2, -25, 5, 13);
    ctx.fillStyle = p.color; rr(-6, -25, 12, 15, 3); ctx.fill(); ctx.stroke();
    if (p.armor > 0) { ctx.fillStyle = '#37474f'; rr(-7, -24, 14, 11, 2); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#78909c'; ctx.fillRect(-4.5, -22, 3.5, 6); ctx.fillRect(1, -22, 3.5, 6); }
    ctx.fillStyle = '#f1c9a5'; ctx.beginPath(); ctx.arc(0, -29, 6, 0, 6.3); ctx.fill(); ctx.stroke();
    ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(0, -30, 6.5, Math.PI, 0); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#111'; ctx.fillRect(f * 2.2, -29.5, 2, 2);
    ctx.save(); ctx.translate(0, -19);
    if (p.swing > 0) { ctx.rotate(f * (p.swing * 10 - 1)); ctx.fillStyle = '#f1c9a5'; ctx.fillRect(0, -2, 14, 4); }
    else {
      ctx.rotate(p.aim); if (Math.cos(p.aim) < 0) ctx.scale(1, -1);
      ctx.save(); ctx.translate(0, OFF[1]); drawGun(w1); ctx.fillStyle = '#e0b996'; ctx.fillRect(2, -2, 5, 4); ctx.restore();
      ctx.save(); ctx.translate(0, OFF[0]); drawGun(w0); ctx.fillStyle = '#f1c9a5'; ctx.fillRect(2, -2, 5, 4); ctx.restore();
    }
    ctx.restore(); ctx.restore();
    if (!isMe && p.alive) {
      ctx.font = 'bold 10px Arial'; ctx.textAlign = 'center'; ctx.fillStyle = '#000'; ctx.fillText(p.name, x + 1, y - 43); ctx.fillStyle = p.color; ctx.fillText(p.name, x, y - 44);
      ctx.fillStyle = '#000a'; ctx.fillRect(x - 11, y - 41, 22, 3); ctx.fillStyle = p.hp > 40 ? '#66bb6a' : '#ef5350'; ctx.fillRect(x - 11, y - 41, 22 * p.hp / 100, 3);
      if (p.armor > 0) { ctx.fillStyle = '#90a4ae'; ctx.fillRect(x - 11, y - 38, 22 * p.armor / 60, 2); }
    }
  }

  function drawPickup(q) {
    var x = q.x, y = q.y - 8 + Math.sin(performance.now() / 300 + q.id) * 2;
    ctx.fillStyle = q.type === 'h' ? '#fff' : (q.type === 'a' ? '#c9a227' : (q.type === 'v' ? '#455a64' : '#37474f')); rr(x - 9, y - 7, 18, 14, 3); ctx.fill(); ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.stroke();
    if (q.type === 'h') { ctx.fillStyle = '#e53935'; ctx.fillRect(x - 5, y - 1.5, 10, 3); ctx.fillRect(x - 1.5, y - 5, 3, 10); }
    else if (q.type === 'v') { ctx.fillStyle = '#90a4ae'; rr(x - 6, y - 5, 12, 10, 2); ctx.fill(); ctx.fillStyle = '#263238'; ctx.fillRect(x - 4, y - 3, 3, 6); ctx.fillRect(x + 1, y - 3, 3, 6); }
    else if (q.type === 'a') { ctx.fillStyle = '#5d4037'; ctx.fillRect(x - 5, y - 3, 3, 7); ctx.fillRect(x - 1, y - 3, 3, 7); ctx.fillRect(x + 3, y - 3, 3, 7); }
    else { ctx.save(); ctx.translate(x - 7, y); drawGun(q.w); ctx.restore(); }
  }

  function drawGame() {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#0b0b0b'; ctx.fillRect(0, 0, sw, sh);
    var sim = S.sim, map = S.map; if (!sim || !map) return;
    var sc = (sh / 380) * ZOOMS[S.zi], vw = sw / sc, vh = sh / sc, hw = map.w - vw, hh = map.h - vh;
    var cx = Math.max(vw / 2, Math.min(map.w - vw / 2, cam.x)), cy = Math.max(vh / 2, Math.min(map.h - vh / 2, cam.y));
    var shx = (Math.random() - .5) * cam.shake, shy = (Math.random() - .5) * cam.shake;
    var L = cx - vw / 2 + shx, T = cy - vh / 2 + shy;
    ctx.save(); ctx.scale(sc, sc); ctx.translate(-L, -T);
    var img = S.imgs[S.mapId];
    if (img && img.complete && img.naturalWidth) ctx.drawImage(img, 0, 0, map.w, map.h);
    else { ctx.fillStyle = '#fff'; ctx.font = '20px Arial'; ctx.fillText('Cargando mapa...', L + 20, T + 40); }
    var i, id, p, pr;
    sim.pk.forEach(drawPickup);
    for (i = 0; i < sim.proj.length; i++) {
      pr = sim.proj[i];
      if (pr.type === 'g') { ctx.fillStyle = '#2e7d32'; ctx.beginPath(); ctx.arc(pr.x, pr.y, 3.5, 0, 6.3); ctx.fill(); ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.stroke(); if (pr.fuse < 0.6 && ((pr.fuse * 14) | 0) % 2) { ctx.fillStyle = '#f44'; ctx.fillRect(pr.x - 1, pr.y - 6, 2, 2); } }
      else if (pr.type === 'r') { ctx.fillStyle = '#ddd'; ctx.save(); ctx.translate(pr.x, pr.y); ctx.rotate(Math.atan2(pr.vy, pr.vx)); ctx.fillRect(-8, -2, 12, 4); ctx.fillStyle = '#e53935'; ctx.fillRect(4, -2, 3, 4); ctx.restore(); }
      else { var sp = Math.hypot(pr.vx, pr.vy), len = Math.min(18, sp * 0.02); ctx.strokeStyle = '#ffe9a0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(pr.x, pr.y); ctx.lineTo(pr.x - pr.vx / sp * len, pr.y - pr.vy / sp * len); ctx.stroke(); }
    }
    for (id in S.players) { p = S.players[id]; if (!p.alive && +id !== S.me && p.resp <= 0 && p.x === 0) continue; if (+id !== S.me) drawPlayer(p, p.rx, p.ry, false); }
    var me = S.players[S.me]; if (me) drawPlayer(me, me.x, me.y, true);
    for (i = 0; i < fx.length; i++) { var f = fx[i]; ctx.globalAlpha = Math.max(0, f.l / f.m); ctx.fillStyle = f.c; ctx.fillRect(f.x - f.s / 2, f.y - f.s / 2, f.s, f.s); }
    ctx.globalAlpha = 1;
    for (i = 0; i < rings.length; i++) { var rg = rings[i]; ctx.globalAlpha = Math.max(0, rg.l / rg.m); ctx.strokeStyle = '#ffcc80'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(rg.x, rg.y, rg.r, 0, 6.3); ctx.stroke(); ctx.fillStyle = '#ff9800'; ctx.globalAlpha *= 0.4; ctx.fill(); }
    ctx.globalAlpha = 1; ctx.restore();
    drawHud(me);
  }

  function drawHud(me) {
    ctx.textAlign = 'left'; ctx.lineWidth = 2;
    if (flash > 0) { ctx.fillStyle = 'rgba(255,0,0,' + Math.min(0.35, flash) + ')'; ctx.fillRect(0, 0, sw, sh); }
    if (me) {
      ctx.fillStyle = '#0009'; rr(60, 8, 170, 38, 8); ctx.fill(); ctx.strokeStyle = '#ddd'; ctx.stroke();
      ctx.fillStyle = '#222'; ctx.fillRect(70, 14, 150, 9); ctx.fillRect(70, 30, 150, 9);
      ctx.fillStyle = me.hp > 35 ? '#c13fd0' : '#e53935'; ctx.fillRect(70, 14, 150 * Math.max(0, me.hp) / 100, 9);
      ctx.fillStyle = '#90a4ae'; ctx.fillRect(70, 30, 150 * Math.max(0, me.armor) / 60, 9);
      ctx.fillStyle = '#0009'; rr(sw - 232, 8, 170, 38, 8); ctx.fill(); ctx.strokeStyle = '#ddd'; ctx.stroke();
      var ws = wsOf(me, true); ctx.textAlign = 'left';
      ctx.fillStyle = '#fff'; ctx.font = 'bold 12px Arial'; ctx.fillText(W[ws[0]].n + ' + ' + W[ws[1]].n, sw - 224, 24);
      ctx.font = '11px Arial'; ctx.fillStyle = '#b0bec5'; ctx.fillText('Espalda: ' + (ws[2] >= 0 ? W[ws[2]].n : '—'), sw - 224, 40);
    }
    var t = Math.max(0, Math.ceil(S.rem)), mm = Math.floor(t / 60), ss = t % 60;
    ctx.textAlign = 'center'; ctx.font = 'bold 20px Arial'; ctx.fillStyle = '#000'; ctx.fillText(mm + ':' + (ss < 10 ? '0' : '') + ss, sw / 2 + 1, 27); ctx.fillStyle = '#fff'; ctx.fillText(mm + ':' + (ss < 10 ? '0' : '') + ss, sw / 2, 26);
    if (me) {
      ctx.font = 'bold 12px Arial'; ctx.fillStyle = '#e8ecd8'; var best = null, id;
      for (id in S.players) if (!best || (S.players[id].kills - S.players[id].deaths) > (best.kills - best.deaths)) best = S.players[id];
      ctx.fillText('Bajas ' + me.kills + '  Muertes ' + me.deaths + '  Puntos ' + (me.kills - me.deaths) + (best ? '   ·   Líder: ' + best.name + ' ' + (best.kills - best.deaths) : ''), sw / 2, 44);
    }
    ctx.font = 'bold 13px Arial';
    for (var i = 0; i < feed.length; i++) { ctx.fillStyle = feed[i].mine ? '#ff5252' : '#ffd54f'; ctx.globalAlpha = Math.min(1, feed[i].t); ctx.fillText(feed[i].s, sw / 2, 64 + i * 15); }
    ctx.globalAlpha = 1;
    if (me && !me.alive) { ctx.font = 'bold 26px Arial'; ctx.fillStyle = '#fff'; ctx.fillText('Reapareciendo: ' + Math.max(1, Math.ceil(me.resp)), sw / 2, sh / 2 + 40); }
    // botones
    var bs = buttons(); ctx.textAlign = 'center';
    for (i = 0; i < bs.length; i++) {
      var b = bs[i]; ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 6.3); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.font = 'bold 14px Arial';
      if (b.k === 'gr') { ctx.fillStyle = '#4caf50'; ctx.beginPath(); ctx.arc(b.x, b.y + 2, 9, 0, 6.3); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillRect(b.x - 2, b.y - 11, 4, 4); ctx.font = 'bold 12px Arial'; ctx.fillText(me ? me.gren : 0, b.x + 20, b.y + 20); }
      else if (b.k === 'wp') { ctx.fillStyle = '#cfd8dc'; ctx.fillRect(b.x - 12, b.y - 3, 17, 5); ctx.fillRect(b.x - 2, b.y + 1, 4, 8); ctx.fillStyle = '#ffd54f'; ctx.fillRect(b.x + 3, b.y - 10, 5, 5); ctx.font = 'bold 9px Arial'; ctx.fillStyle = '#fff'; ctx.fillText('arma', b.x, b.y + 19); }
      else if (b.k === 'take') { ctx.font = 'bold 12px Arial'; ctx.fillStyle = '#fff'; ctx.fillText('Tomar', b.x, b.y - 2); ctx.font = '10px Arial'; ctx.fillStyle = '#ffd54f'; ctx.fillText(S.near ? W[S.near.w].n : '', b.x, b.y + 11); }
      else if (b.k === 'ml') { ctx.fillStyle = '#f1c9a5'; rr(b.x - 9, b.y - 7, 18, 14, 4); ctx.fill(); }
      else ctx.fillText(b.t, b.x, b.y + 5);
    }
    // palancas
    var dl = { x: sw * 0.13, y: sh * 0.72 }, dr = { x: sw * 0.87, y: sh * 0.72 };
    drawStick(stL, dl, 'rgba(120,160,255,'); drawStick(stR, dr, 'rgba(255,120,120,');
  }
  function drawStick(s, def, col) {
    var bx = s ? s.sx : def.x, by = s ? s.sy : def.y, kx = bx, ky = by;
    if (s) { var d = stick(s); kx = bx + d.x * SR; ky = by + d.y * SR; }
    ctx.lineWidth = 3; ctx.strokeStyle = col + (s ? '.75)' : '.35)'); ctx.fillStyle = col + '.18)';
    ctx.beginPath(); ctx.arc(bx, by, SR, 0, 6.3); ctx.fill(); ctx.stroke();
    ctx.fillStyle = col + (s ? '.65)' : '.3)'); ctx.beginPath(); ctx.arc(kx, ky, 24, 0, 6.3); ctx.fill(); ctx.stroke();
  }

  function frame(t) {
    requestAnimationFrame(frame);
    var dt = Math.min(0.05, (t - last) / 1000); last = t;
    if (S.screen === 'game' || S.overlay) { try { updateGame(dt); drawGame(); } catch (e) { window.__err = e; window.__stack = e.stack; } }
  }
  requestAnimationFrame(frame);
  window.__LM = { S: S, onEvent: onEvent, hostMsg: hostMsg, press: press };
})();
