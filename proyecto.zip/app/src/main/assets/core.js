/* Little Militia - núcleo (física + reglas). Funciona en navegador y en node. */
(function (root) {
  'use strict';
  var LM = root.LM = root.LM || {};
  var PW = 18, PH = 30;
  LM.PW = PW; LM.PH = PH;
  LM.GRAV = 1500;

  // n,dmg,rate,mag,res,spd,spr,rel,pel,life,rocket,gl(largo arma),gh(grosor),col
  LM.WEAPONS = [
    { n: 'Pistola', dmg: 14, rate: 0.28, mag: 12, res: 999, spd: 900, spr: 0.02, rel: 1.0, pel: 1, life: 1.1, gl: 11, gh: 4, col: '#cfcfcf' },
    { n: 'Uzi', dmg: 8, rate: 0.075, mag: 30, res: 120, spd: 850, spr: 0.07, rel: 1.4, pel: 1, life: 0.9, gl: 15, gh: 5, col: '#9aa0a6' },
    { n: 'Fusil AK', dmg: 12, rate: 0.11, mag: 30, res: 90, spd: 980, spr: 0.04, rel: 1.8, pel: 1, life: 1.2, gl: 24, gh: 5, col: '#8d6e4a' },
    { n: 'Escopeta', dmg: 9, rate: 0.85, mag: 6, res: 24, spd: 800, spr: 0.17, rel: 2.0, pel: 7, life: 0.3, gl: 22, gh: 6, col: '#a0522d' },
    { n: 'Francotirador', dmg: 75, rate: 1.2, mag: 5, res: 15, spd: 2000, spr: 0.0, rel: 2.2, pel: 1, life: 1.3, gl: 32, gh: 4, col: '#4c5b46' },
    { n: 'Lanzacohetes', dmg: 85, rate: 1.4, mag: 1, res: 5, spd: 520, spr: 0.0, rel: 2.4, pel: 1, life: 3.0, rocket: true, rad: 85, gl: 28, gh: 8, col: '#56633f' }
  ];
  LM.wname = function (w) { return w >= 0 ? LM.WEAPONS[w].n : (w === -1 ? 'Granada' : 'Golpe'); };
  LM.GREN_RAD = 95; LM.GREN_DMG = 90;

  // ---- Mapa ----
  LM.GameMap = function (def) {
    this.def = def; this.w = def.w; this.h = def.h; this.cell = def.cell; this.cw = def.cw; this.ch = def.ch;
    var bin = (typeof atob === 'function') ? atob(def.mask) : Buffer.from(def.mask, 'base64').toString('binary');
    var n = this.cw * this.ch; this.g = new Uint8Array(n);
    for (var i = 0; i < n; i++) this.g[i] = (bin.charCodeAt(i >> 3) >> (7 - (i & 7))) & 1;
  };
  LM.GameMap.prototype.solidCell = function (cx, cy) {
    if (cx < 0 || cy < 0 || cx >= this.cw || cy >= this.ch) return 1;
    return this.g[cy * this.cw + cx];
  };
  LM.GameMap.prototype.solidAt = function (x, y) {
    return this.solidCell(Math.floor(x / this.cell), Math.floor(y / this.cell));
  };
  LM.GameMap.prototype.boxHit = function (l, t, r, b) {
    var c = this.cell, x0 = Math.floor(l / c), x1 = Math.floor((r - 0.01) / c), y0 = Math.floor(t / c), y1 = Math.floor((b - 0.01) / c);
    for (var cy = y0; cy <= y1; cy++) for (var cx = x0; cx <= x1; cx++) if (this.solidCell(cx, cy)) return true;
    return false;
  };

  // ---- Jugadores ----
  LM.newPlayer = function (id, name, color) {
    var p = { id: id, name: name || ('J' + id), color: color || '#6c8', x: 0, y: 0, vx: 0, vy: 0, rx: 0, ry: 0, face: 1, aim: 0,
      hp: 100, fuel: 100, alive: false, onGround: false, jet: false, cur: 0, cd: 0, rl: 0, mcd: 0, gcd: 0,
      kills: 0, deaths: 0, resp: 0, sx: 0, lastSeen: 0, hurt: 0 };
    LM.loadout(p); return p;
  };
  LM.loadout = function (p) {
    var W = LM.WEAPONS; p.w = [1, 0]; p.mag = [W[1].mag, W[0].mag]; p.res = [W[1].res, W[0].res];
    p.gren = 3; p.cur = 0; p.rl = 0; p.cd = 0.3;
  };
  LM.applyPickup = function (p, pk) {
    var W = LM.WEAPONS;
    if (pk.type === 'w') {
      var s = p.w.indexOf(pk.w);
      if (s < 0) { s = p.cur; p.w[s] = pk.w; p.mag[s] = W[pk.w].mag; p.res[s] = W[pk.w].res; p.rl = 0; }
      else { p.res[s] = W[pk.w].res; p.mag[s] = W[pk.w].mag; }
    } else if (pk.type === 'a') {
      for (var i = 0; i < 2; i++) { var w = W[p.w[i]]; if (w.res < 900) p.res[i] = Math.min(w.res + w.mag, p.res[i] + w.mag * 2); }
      p.gren = Math.min(5, p.gren + 2);
    }
  };

  // Mueve un cuerpo con colisión contra el mapa
  LM.moveBody = function (map, b, dt) {
    var hw = PW / 2, H = PH, i, n, nx, ny;
    var guard = 0;
    while (map.boxHit(b.x - hw, b.y - H, b.x + hw, b.y) && guard++ < 60) b.y -= 1;
    var dx = b.vx * dt; n = Math.max(1, Math.ceil(Math.abs(dx) / 2)); var sx = dx / n;
    for (i = 0; i < n; i++) {
      nx = b.x + sx;
      if (!map.boxHit(nx - hw, b.y - H, nx + hw, b.y)) { b.x = nx; }
      else {
        var stepped = false;
        if (b.onGround) {
          for (var up = 1; up <= 7; up++) {
            if (!map.boxHit(nx - hw, b.y - H - up, nx + hw, b.y - up)) { b.x = nx; b.y -= up; stepped = true; break; }
          }
        }
        if (!stepped) { b.vx = 0; break; }
      }
    }
    var dy = b.vy * dt; n = Math.max(1, Math.ceil(Math.abs(dy) / 2)); var sy = dy / n; b.onGround = false;
    for (i = 0; i < n; i++) {
      ny = b.y + sy;
      if (!map.boxHit(b.x - hw, ny - H, b.x + hw, ny)) { b.y = ny; }
      else { if (sy > 0) b.onGround = true; b.vy = 0; break; }
    }
    if (!b.onGround && b.vy >= 0 && map.boxHit(b.x - hw, b.y - H + 1, b.x + hw, b.y + 1)) b.onGround = true;
  };

  // Física del jugador (inp: {mx, up} o null si está muerto)
  LM.physPlayer = function (map, p, dt, inp) {
    var mx = inp ? inp.mx : 0, up = inp ? inp.up : false;
    var tv = mx * 185, acc = p.onGround ? 2600 : 1000;
    var dv = tv - p.vx, m = acc * dt; p.vx += Math.max(-m, Math.min(m, dv));
    if (up && p.fuel > 0) {
      p.vy -= 2750 * dt; if (p.vy < -330) p.vy = -330;
      p.fuel -= 34 * dt; if (p.fuel < 0) p.fuel = 0; p.jet = true;
      if (p.onGround) p.vy = Math.min(p.vy, -200);
    } else {
      p.jet = false;
      p.fuel = Math.min(100, p.fuel + (p.onGround ? 55 : 10) * dt);
    }
    p.vy += LM.GRAV * dt; if (p.vy > 850) p.vy = 850;
    LM.moveBody(map, p, dt);
    if (p.onGround && p.vy > 0) p.vy = 0;
    p.sx += Math.abs(p.vx) * dt * 0.09;
  };

  // ---- Simulación (proyectiles, daño, pickups) ----
  LM.Sim = function (map, isHost, cb) {
    this.map = map; this.host = isHost; this.players = {}; this.proj = []; this.pk = []; this.pkId = 0; this.pkT = 3;
    var nop = function () { };
    this.cb = Object.assign({ fx: nop, hit: nop, kill: nop, explosion: nop, pickupSpawn: nop, pickupGot: nop, respawn: nop }, cb || {});
  };
  var S = LM.Sim.prototype;

  S.addProj = function (o) { this.proj.push(o); return o; };

  S.damage = function (p, ownerId, dmg, wid, x, y) {
    if (!this.host || !p.alive) return;
    p.hp -= dmg; p.hurt = 0.25;
    this.cb.hit(p, ownerId, dmg, x, y);
    if (p.hp <= 0) {
      p.hp = 0; p.alive = false; p.deaths++; p.resp = 4;
      var o = this.players[ownerId];
      if (o && ownerId !== p.id) o.kills++; else if (ownerId === p.id) p.kills = Math.max(0, p.kills - 1);
      this.cb.kill(p.id, ownerId, wid);
    }
  };

  S.explode = function (x, y, r, ownerId, wid, dmg, gid) {
    if (!this.host) return;
    for (var id in this.players) {
      var p = this.players[id]; if (!p.alive) continue;
      var d = Math.hypot(p.x - x, (p.y - 15) - y);
      if (d < r) {
        var f = 1 - d / r; var dd = dmg * f; if (p.id === ownerId) dd *= 0.5;
        this.damage(p, ownerId, Math.max(1, dd), wid, p.x, p.y - 15);
      }
    }
    this.cb.explosion(x, y, r, ownerId, wid, gid);
  };

  S.melee = function (ownerId, x, y, face) {
    if (!this.host) return;
    for (var id in this.players) {
      var p = this.players[id]; if (!p.alive || p.id === ownerId) continue;
      var dx = (p.x - x) * face, dy = (p.y - 15) - (y - 15);
      if (dx > -6 && dx < 30 && Math.abs(dy) < 22) this.damage(p, ownerId, 35, -2, p.x, p.y - 15);
    }
  };

  S.pickSpawn = function () {
    var sp = this.map.def.spawns, best = null, bd = -1;
    for (var k = 0; k < 7; k++) {
      var c = sp[Math.floor(Math.random() * sp.length)], md = 1e9;
      for (var id in this.players) { var p = this.players[id]; if (p.alive) md = Math.min(md, Math.hypot(p.x - c[0], p.y - c[1])); }
      if (md > bd) { bd = md; best = c; }
    }
    return best;
  };

  S.update = function (dt) {
    var map = this.map, i, pr, id, p;
    for (i = this.proj.length - 1; i >= 0; i--) {
      pr = this.proj[i];
      if (pr.type === 'g') {
        pr.fuse -= dt; pr.vy += 1100 * dt;
        var n = Math.max(1, Math.ceil(Math.hypot(pr.vx, pr.vy) * dt / 3)), sx = pr.vx * dt / n, sy = pr.vy * dt / n;
        for (var s = 0; s < n; s++) {
          if (map.solidAt(pr.x + sx, pr.y)) { pr.vx *= -0.5; sx = pr.vx * dt / n; } else pr.x += sx;
          if (map.solidAt(pr.x, pr.y + sy)) { if (Math.abs(pr.vy) > 60) { pr.vy *= -0.45; } else pr.vy = 0; pr.vx *= 0.85; sy = pr.vy * dt / n; } else pr.y += sy;
        }
        if (pr.fuse <= 0) {
          if (this.host) { this.explode(pr.x, pr.y, LM.GREN_RAD, pr.o, -1, LM.GREN_DMG, pr.gid); this.proj.splice(i, 1); }
          else if (pr.fuse < -1.5) this.proj.splice(i, 1);
        }
        continue;
      }
      pr.life -= dt;
      if (pr.life <= 0) {
        if (pr.type === 'r' && this.host) this.explode(pr.x, pr.y, LM.WEAPONS[5].rad, pr.o, 5, LM.WEAPONS[5].dmg, 0);
        this.proj.splice(i, 1); continue;
      }
      var steps = Math.max(1, Math.ceil(Math.hypot(pr.vx, pr.vy) * dt / 3)), dead = false;
      for (var k = 0; k < steps && !dead; k++) {
        pr.x += pr.vx * dt / steps; pr.y += pr.vy * dt / steps;
        if (map.solidAt(pr.x, pr.y)) {
          dead = true;
          if (pr.type === 'r') { if (this.host) this.explode(pr.x, pr.y, LM.WEAPONS[5].rad, pr.o, 5, LM.WEAPONS[5].dmg, 0); }
          else this.cb.fx('spark', pr.x - pr.vx * 0.004, pr.y - pr.vy * 0.004);
          break;
        }
        for (id in this.players) {
          p = this.players[id];
          if (!p.alive || p.id === pr.o) continue;
          if (pr.x > p.x - PW / 2 - 1 && pr.x < p.x + PW / 2 + 1 && pr.y > p.y - PH - 1 && pr.y < p.y + 1) {
            dead = true;
            if (pr.type === 'r') { if (this.host) this.explode(pr.x, pr.y, LM.WEAPONS[5].rad, pr.o, 5, LM.WEAPONS[5].dmg, 0); }
            else if (this.host) {
              var head = pr.y < p.y - PH + 8;
              this.damage(p, pr.o, LM.WEAPONS[pr.w].dmg * (head ? 1.6 : 1), pr.w, pr.x, pr.y);
            }
            break;
          }
        }
      }
      if (dead) this.proj.splice(i, 1);
      else if (pr.type === 'r') this.cb.fx('smoke', pr.x, pr.y);
    }
    if (this.host) this.updateHost(dt);
  };

  S.updateHost = function (dt) {
    var id, p, i;
    for (id in this.players) {
      p = this.players[id];
      if (!p.alive && p.resp > 0 && this.active) {
        p.resp -= dt;
        if (p.resp <= 0) { var sp = this.pickSpawn(); this.respawnAt(p, sp[0], sp[1]); this.cb.respawn(p, sp[0], sp[1]); }
      }
      if (p.hurt > 0) p.hurt -= dt;
    }
    if (!this.active) return;
    this.pkT -= dt;
    if (this.pkT <= 0) {
      this.pkT = 4 + Math.random() * 4;
      if (this.pk.length < 10) {
        var sp2 = this.map.def.spawns, c = sp2[Math.floor(Math.random() * sp2.length)], ok = true;
        for (i = 0; i < this.pk.length; i++) if (Math.hypot(this.pk[i].x - c[0], this.pk[i].y - c[1]) < 50) ok = false;
        if (ok) {
          var r = Math.random(), pk = { id: ++this.pkId, x: c[0], y: c[1] };
          if (r < 0.5) { pk.type = 'w'; pk.w = 1 + Math.floor(Math.random() * 5); } else if (r < 0.75) pk.type = 'h'; else pk.type = 'a';
          this.pk.push(pk); this.cb.pickupSpawn(pk);
        }
      }
    }
    for (i = this.pk.length - 1; i >= 0; i--) {
      var q = this.pk[i];
      for (id in this.players) {
        p = this.players[id];
        if (!p.alive) continue;
        if (Math.abs(p.x - q.x) < 16 && Math.abs((p.y - 14) - (q.y - 8)) < 22) {
          if (q.type === 'h' && p.hp >= 100) continue;
          this.pk.splice(i, 1);
          if (q.type === 'h') p.hp = Math.min(100, p.hp + 50);
          this.cb.pickupGot(q, p);
          break;
        }
      }
    }
  };

  S.respawnAt = function (p, x, y) {
    p.x = x; p.y = y; p.rx = x; p.ry = y; p.vx = 0; p.vy = 0; p.hp = 100; p.fuel = 100; p.alive = true; p.resp = 0; p.jet = false;
    LM.loadout(p);
  };

  S.resetMatch = function () {
    this.proj.length = 0; this.pk.length = 0; this.pkT = 2; this.active = true;
    for (var id in this.players) { var p = this.players[id]; p.kills = 0; p.deaths = 0; var sp = this.pickSpawn(); this.respawnAt(p, sp[0], sp[1]); p.resp = 0; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
